// Cloudflare Worker (plan gratuito, 100.000 peticiones/día)
// Convierte  https://TU-WORKER.workers.dev/dm/<id>  en una redirección 302 al m3u8 con token FRESCO.
// El enlace en tu lista nunca cambia; el token se pide justo cuando pulsas play.
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36";

export default {
  async fetch(request) {
    const m = new URL(request.url).pathname.match(/^\/dm\/([a-z0-9]{4,10})$/i);
    if (!m) return new Response("IPTV resolver OK", { status: 200 });
    const api = `https://www.dailymotion.com/player/metadata/video/${m[1]}?embedder=${encodeURIComponent("https://www.dailymotion.com/")}`;
    try {
      const r = await fetch(api, {
        headers: { "User-Agent": UA, "Referer": "https://www.dailymotion.com/" },
        cf: { cacheTtl: 60, cacheEverything: true },       // evita saturar a Dailymotion
      });
      const j = await r.json();
      const url = j?.qualities?.auto?.[0]?.url;
      if (!url) return new Response("Sin stream (canal offline)", { status: 502 });
      return Response.redirect(url, 302);
    } catch (e) {
      return new Response("Error resolviendo: " + e.message, { status: 502 });
    }
  },
};
